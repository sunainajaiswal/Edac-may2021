class pattern5
{
public static void main(String args[])
{
int a=1; 
int i,j;
for(i=9; i>=1; i-- )
{
   for(j=1; j<=i*2; j++)
   {
      System.out.print(" ");
   }
   for(j=i; j<=9; j++)
   {
      System.out.print(j+" ");
   }
   for(j=8; j>=i; j--)
   {
      System.out.print(j+" "); 
   }
    System.out.println();
    a++;
}
}
}