public class pattern1  
{    
public static void main(String args[])   
{      
int k=1;         
for (int i=0; i<9; i++)   
{        
for (int j=9-i; j>1; j--)   
{    
System.out.print(" ");   
}     
for (int j=0; j<=i; j++)   
{         
System.out.print(k+i+" ");   
}     
System.out.println();   
}   
}   
}