class assign15
{
public static void main(String[] args)
{
 int k=5;
 for (int i= 4; i>=0 ; i--)
 {
  for (int j=0; j<=i; j++)
  {
    System.out.print(k-j);
  }
 System.out.println();
}  
}
}