class star13
{  
public static void main(String[] args)  
{  
int i, j, k;              
for (i= 0; i< 4 ; i++)  
{  
for (j=0; j<i; j++)  
{  
System.out.print(" ");  
}  
for (k=i; k<=4; k++)   
{   
System.out.print(" "+"*");   
}   
System.out.println("");   
}   
for (i= 4; i>= 0; i--)  
{  
for (j=0; j<i; j++)  
{  
System.out.print(" ");  
}  
for (k=i; k<=4; k++)  
{  
System.out.print(" "+"*");  
}  
System.out.println("");  
}   
}  
}  