public class star7  
{  
public static void main(String args[])  
{  
int row, i, j, k = 1;   
row = 5;  
k = row - 1;  
for (j = 1; j<= row; j++)  
{  
for (i = 1; i<= k; i++)  
{  
System.out.print(" ");  
}  
k--;  
for (i = 1; i <= 2 * j - 1; i++)  
{  
System.out.print("*");  
}  
System.out.println("");  
}  
k = 1;  
for (j = 1; j<= row - 1; j++)  
{  
for (i = 1; i<= k; i++)  
{  
System.out.print(" ");  
}  
k++;  
for (i = 1; i<= 2 * (row - j) - 1; i++)  
{  
System.out.print("*");  
}  
System.out.println("");  
}  
}  
}  