/*
04.Write a program that initializes 2 byte type of variables. 
Add the values of these variables and store in a byte type of variable. 
[Note: primitive down casting is required in this program ] */
class assg4
{
public static void main(String args[])
{
byte a=120;
byte b=28;
//byte b=228 cannot define it like this bcoz it will be out of limit;
int c;
c= a+b;
System.out.println(c);
}
}