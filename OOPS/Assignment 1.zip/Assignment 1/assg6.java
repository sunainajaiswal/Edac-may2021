/*06.Write a program that takes radius of a circle as input.
Read the entered radius using Scanner class. 
Then calculate and print the area and circumference of the circle*/

import java.util.*;
class assg6
{
public static void main(String args[])
{
System.out.println("Enter the radius :");
Scanner sc = new Scanner (System.in);
float r = sc.nextFloat();
float c = 2*(22/7)*r;
float a = (22/7)*r*r;
System.out.println("Circumference : " +c);
System.out.println("Area : " +a);
}
}