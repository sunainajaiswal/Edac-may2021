//13.Program to find greatest in 3 numbers. 
//[ once using if else statement and then using ternary operator ( logical operator) ]

import java.util.*;
class assg13
{
public static void main(String args[])
{
Scanner sc= new Scanner (System.in);
int i,j,k;

System.out.println("Enter First number ");
i=sc.nextInt();

System.out.println("Enter second number ");
j=sc.nextInt();

System.out.println("Enter third number ");
k=sc.nextInt();

if ( i>j && i>k)
System.out.println("The greates number is "+i);

else if (j>i && j>k)
System.out.println("The greates number is "+j);

else
System.out.println("The greatest number is "+k);
}
} 