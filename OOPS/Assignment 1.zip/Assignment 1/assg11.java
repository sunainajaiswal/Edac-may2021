//11.Write a program to swap two numbers without using third variable.

import java.util.*;
class assg11
{
public static void main(String args[])
{
int i,j;
Scanner sc = new Scanner (System.in);
System.out.println("Enter the first number before swap : ");
i=sc.nextInt();
System.out.println("Enter the second number before swap : ");
j=sc.nextInt();
i=i+j;
j=i-j;
i=i-j;
System.out.println("After swap : " +i+ " " +j);
}
}