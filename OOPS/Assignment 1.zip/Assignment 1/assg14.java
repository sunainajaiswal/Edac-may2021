//14.Program to check that entered year is a leap year or not

import java.util.*;
class Leapyear
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int year=sc.nextInt();
		if (year%400==0)
		{
			System.out.println("It is Leap Year.");
		}
		else if(year%4==0)
			System.out.println("It is Leap Year.");
		else 
		System.out.println("It is Not Leap Year.");
	}
}

