/*07.Write a program to calculate sum of 5 subject’s marks & find percentage. 
Take the obtained marks from user using Scanner class.
Output should be in this format [ percentage marks = 99 % ]. 
Use concatenation operator here */

import java.util.*;
public class assg7 
{
public static void main(String[] args) 
{
int cs, civil, it, etc, mech; 
float total, Percentage, Average;

Scanner sc = new Scanner(System.in);		
System.out.print(" Please Enter the Five Subjects Marks : ");

cs = sc.nextInt();	
civil = sc.nextInt();	
it = sc.nextInt();	
etc = sc.nextInt();	
mech = sc.nextInt();	
		
total = cs + civil + it + etc + mech;
Average = total / 5;
Percentage = (total / 500) * 100;
System.out.println(" Total =  " + total);
System.out.println(" Average =  " + Average);
System.out.println(" Marks =  " + Percentage);
}
}