/*15.Accept person’s gender (character m for male and f for female), age (integer), 
as input and then check whether person is eligible for marriage or not */

import java.util.*;
class assg15
{
public static void main(String args[])
{
String gender 
}
}