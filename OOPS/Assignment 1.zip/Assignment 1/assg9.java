/* 09.Write a program to read the days (eg. 670 days) as integer value using Scanner class. 
Now convert the entered days into complete years, months and days and print them */


import java.util.Scanner;
class assg9
{
    public static void main(String args[])
    {
        int x, y, w, day;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the number of days:");
        x = s.nextInt();
        y = x / 365;
        x = x % 365;
        System.out.println("No. of years:"+y);
        w = x / 7;
        x = x % 7;
        System.out.println("No. of weeks:"+w);
        day = x;
        System.out.println("No. of days:"+day);
    }
}
