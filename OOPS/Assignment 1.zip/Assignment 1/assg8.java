/*08.Write a program to find the simple interest. 
Take the principle amount, rate of interest and time from user using Scanner class*/

import java.util.Scanner;
class assg8
{
public static void main(String args[]) 
{
        float p, r, t;
        Scanner scan = new Scanner(System.in);
        System.out.print("Principal : ");
        p = scan.nextFloat();
        System.out.print("Rate of interest : ");
        r = scan.nextFloat();
        System.out.print("Time period : ");
        t = scan.nextFloat();
        interest = (p * r * t) / 100;
        System.out.print("Simple Interest is: " + interest);
}
}