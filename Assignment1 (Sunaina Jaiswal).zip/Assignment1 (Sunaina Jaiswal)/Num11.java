import java.util.*;
class Num11
{
public static void main (String args[])
{
Scanner sc= new Scanner (System.in);
System.out.println("Radius : " );
Double r=sc.nextDouble();
Double c=Math.PI*2*r;
System.out.println("Circumference : " +c);
Double a=Math.PI*r*r;
System.out.println("Area: " +a);
}
}