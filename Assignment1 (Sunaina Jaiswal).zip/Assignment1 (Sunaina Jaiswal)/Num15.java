import java.util.*;
class Num15
{
public static void main(String args[])
{
Scanner sc=new Scanner (System.in);
System.out.println("Enter Two Numbers : ");
int i= sc.nextInt();
int j= sc.nextInt();
int swap;
System.out.println("I : " +i);
System.out.println("J : " +j);
swap=i;
i=j;
j=swap;
System.out.println("After Swap : ");
System.out.println("I : " +i);
System.out.println("J : " +j);
}
}
//i=i+j
//j=i-j
//i=i-j