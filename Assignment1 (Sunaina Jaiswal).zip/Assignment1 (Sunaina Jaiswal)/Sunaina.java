public class Sunaina
{
public static void main (String args[])
{
System.out.println("First : " + args[0]);
}

}