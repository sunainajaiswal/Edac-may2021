import java.util.*;

public class Num3
{
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
int i= sc.nextInt();
int j= sc.nextInt();
System.out.print("Test Data : ");
System.out.print(+i);
System.out.print("/");
System.out.print(+j);
int k= i/j;
System.out.println("Expected Output : " + k);
}
}