import java.util.*;

public class Add
{
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter 2 Numbers ");
int i= sc.nextInt();
int j= sc.nextInt();
int k= i+j;
System.out.println("Addition : " + k);
}
}