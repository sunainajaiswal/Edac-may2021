import java.util.*;
public class Num5
{
public static void main (String args[])
{
Scanner sc= new Scanner(System.in);
System.out.print("Input First Number= " );
int i= sc.nextInt();
System.out.print("Input second number= ");

int j= sc.nextInt();
int k= i*j;
System.out.println("Expected Output");
System.out.print(+i);
System.out.print("*");
System.out.print(+j);
System.out.print("=");
System.out.print(+k);

}
}