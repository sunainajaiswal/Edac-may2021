import java.util.*;

public class Num6
{
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
int i= sc.nextInt();
System.out.println("Enter first number : " +i);
int j= sc.nextInt();
System.out.println("Enter second number : "+j);
int k= i+j;
int l= i-j;
int m= i*j;
int n= i/j;
int o= i%j;
System.out.println("Addition : " +k);
System.out.println("Subtract : " +l);
System.out.println("Multiplication : " +m);
System.out.println("Division : " +n);
System.out.println("Mod : " +o);
}
}