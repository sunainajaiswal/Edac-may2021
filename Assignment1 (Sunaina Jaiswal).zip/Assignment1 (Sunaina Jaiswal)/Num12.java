import java.util.*;
class Num12
{
public static void main (String args[])
{
Scanner sc= new Scanner(System.in);
System.out.println("Enter 3 Numbers : ");
int i= sc.nextInt();
int j= sc.nextInt();
int k= sc.nextInt();
int a= (i+j+k)/3;
System.out.println("Average : " +a);
}
}