import java.util.*;
public class Num17
{
 public static void main(String args[])
 {
  long a, b;
  int i = 0, c = 0;
  int[] sum = new int[20];
  Scanner sc = new Scanner(System.in);

System.out.print("Input first binary number: ");
a = sc.nextLong();
System.out.print("Input second binary number: ");
b = sc.nextLong();

  while (a != 0 || b != 0) 
  {
   sum[i++] = (int)((a % 10 + b % 10 + c) % 2);
   c = (int)((a % 10 + b % 10 + c) / 2);
   a = a / 10;
   b = b / 10;
  }
  if (c != 0) {
   sum[i++] = c;
  }
  --i;
  System.out.print("Sum of two binary numbers: ");
  while (i >= 0) {
   System.out.print(sum[i--]);
  }
   System.out.print("\n");  
 }
}