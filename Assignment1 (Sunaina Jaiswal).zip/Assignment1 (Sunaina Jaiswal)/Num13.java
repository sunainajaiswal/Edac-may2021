import java.util.*;
class Num13
{
public static void main(String args[])
{
Scanner sc= new Scanner (System.in);
System.out.println("Width : ");
Double i=sc.nextDouble();
System.out.println("Height : ");
Double j=sc.nextDouble();
Double c=2*(i+j);
Double a=i*j;
System.out.println("Circumferece of Rectangle : " +c);
System.out.println("Area of Rectangle : " +a);
}
}