class AmericanFlag
{
	public static void main(String[] args)
	{
		for(int i=1; i<=15;i++)
		{
			if(i<=6)
			{
				if(i%2==1)
				{
					System.out.println("* * * * * * = = = = = = = = = = = = = = =");
				}
				else
				{
					System.out.println(" * * * * *  = = = = = = = = = = = = = = =");
				}
			}
			else
			{
				    System.out.println("= = = = = = = = = = = = = = = = = = = = =");
			}
		}
		
	}	

}



/*
import java.util.*;
class Num14
{
   public static void main(String[] args)
    {
        System.out.println("* * * * * * ==================================");
        System.out.println(" * * * * *  ==================================");
        System.out.println("* * * * * * ==================================");
        System.out.println(" * * * * *  ==================================");
        System.out.println("* * * * * * ==================================");
        System.out.println(" * * * * *  ==================================");
        System.out.println("* * * * * * ==================================");
        System.out.println(" * * * * *  ==================================");
        System.out.println("* * * * * * ==================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
    }
}
*/