import java.util.*;

public class Num7
{
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter the Number : ");
int i= sc.nextInt();
for (int j=1; j<=10; j++)
{
System.out.println(i+" * "+j+" = "+i*j);
}
}
}